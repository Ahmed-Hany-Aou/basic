<footer class="footer py-3">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-sm-6 text-sm-start text-center mb-2 mb-sm-0">
                &copy; <script>document.write(new Date().getFullYear())</script> Ahmed Hany. All rights reserved.
            </div>
            <div class="col-sm-6 text-sm-end text-center">
                Crafted with <i class="mdi mdi-heart text-danger"></i> by Ahmed Hany
            </div>
        </div>
    </div>
</footer>
